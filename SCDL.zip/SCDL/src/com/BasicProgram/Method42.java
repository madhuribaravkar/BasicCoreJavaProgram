package com.BasicProgram;
import java.util.Scanner;
public class Method42 {
	public static void findEvenOdd(int n){
		if(n%2==0){
			System.out.println("Number is even: "+n);
		}
		else
		{
			System.out.println( "Number is odd: "+n);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println("Enter  Number:");
  Scanner sc=new Scanner(System.in);
  int n=sc.nextInt();
 
  findEvenOdd(n);
  
	}

}
