package com.BasicProgram;
import java.util.Scanner;
public class Addnumber8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int add=0,a,b;
System.out.println("Enter Two Number:");
Scanner sc=new Scanner(System.in);
a=sc.nextInt();
b=sc.nextInt();
add=a+b;
System.out.println("Add Two Number: "+add);
	}

}
