package com.BasicProgram;
import java.util.Scanner;
public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
System.out.println("Enter your first number:");

Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
System.out.println("Enter your two number:");
int b=sc.nextInt();
int c=a;
for(int i=1;i<b;i++){
	 c=c*a;
}
System.out.println(""+c);
	}

}
