package com.BasicProgram;
import java.util.Scanner;
class Test{
	int a,b,c;
	void getdata(int x,int y){
		a=x;
		b=y;
	}
	void add(){
		c=a+b;
		System.out.println("Addition= "+c);
	}
}
public class MultipleClass46 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Test t=new Test();
t.getdata(200, 100);
t.add();
	}

}
