package com.BasicProgram;
import java.util.Scanner;
public class StaticBlock44 {
    static{
    	System.out.println("static block is invoked");
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("Hello main");
	}

}
