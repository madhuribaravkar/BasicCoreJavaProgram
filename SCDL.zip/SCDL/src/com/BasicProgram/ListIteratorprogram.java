package com.BasicProgram;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Integer>array=new ArrayList<Integer>();
array.add(1);
array.add(2);
array.add(3);
array.add(4);
array.add(5);

ListIterator<Integer>li=array.listIterator();
while(li.hasNext()) {
	System.out.println(li.next());
}
System.out.println("---------------");
while(li.hasPrevious()) {
	System.out.println(li.previous());
}
	}

}
