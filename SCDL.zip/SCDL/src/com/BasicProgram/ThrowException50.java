package com.BasicProgram;
import java.util.Scanner;
public class ThrowException50 {

	public static void main(String[] args) {
    		
    
	}

}
