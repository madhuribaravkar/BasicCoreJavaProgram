package com.BasicProgram;
import java.util.Scanner;
public class Palindrome31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter Number:");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int temp,rev=0,rem;
temp=n;
while(n>0){
	rem=n%10;
	rev=rev*10+rem;
	n=n/10;
	
}
if(temp==rev){
	System.out.println("Number is palindrome");
}
else{
	System.out.println("Number is not palindrome");
}

	}

}
