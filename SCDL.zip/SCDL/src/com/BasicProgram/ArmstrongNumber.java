package com.BasicProgram;
import java.util.Scanner;
public class ArmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter Number:");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int rem,arm=0;
int temp=n;
while(n>0){
	rem=n%10;
	arm=arm+(rem*rem*rem);
	n=n/10;
}
if(temp==arm){
	System.out.println("Armstrong number");
}
else{
	System.out.println("Not Armstrong Number");
}
	

}
}
