package com.BasicProgram;
import java.util.Scanner;
public class RemoveSpace40 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="  madhuri     baravkar";
s1=s1.replaceAll("\\s", "");
System.out.println(s1);
	}

}
