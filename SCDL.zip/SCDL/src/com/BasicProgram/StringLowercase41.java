package com.BasicProgram;
import java.util.Scanner;
public class StringLowercase41 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter String:");
Scanner sc=new Scanner(System.in);
String ch=sc.next();
System.out.println("Lowercase String: "+ch.toLowerCase());
	}

}
