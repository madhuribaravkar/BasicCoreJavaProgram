package com.BasicProgram;
import java.util.Scanner;
public class PrintAllAlbhabet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c;
for(c='A';c<='Z';c++){
	System.out.print("\t"+c);
}
	}

}
