package com.BasicProgram;
import java.util.Scanner;
public class ReverseNumber20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int n,rem,rev=0;
     System.out.println("Enter number:");
     Scanner sc=new Scanner(System.in);
     n=sc.nextInt();
     
     while(n!=0){
    	 rem=n%10;
    	 rev=rev*10+rem;
    	 n=n/10;
    	 }
     System.out.println("Reverse Number:"+rev);
     
	}

}
