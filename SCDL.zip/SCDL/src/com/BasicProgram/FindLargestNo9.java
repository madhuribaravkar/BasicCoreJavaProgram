package com.BasicProgram;
import java.util.Scanner;
public class FindLargestNo9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter Number:");
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
int c=sc.nextInt();
if(a>=b&&a>=c){
	System.out.println("A is largest number: "+a);
}
else if(b>=a&&b>=c){
	System.out.println("B is largest number: "+b);
}
else
{
	System.out.println("C is largest number: "+c);
}
	}

}
