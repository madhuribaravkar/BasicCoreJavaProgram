package com.BasicProgram;
import java.util.Scanner;
public class EnhancedForLoop23 {

	public static void main(String[] args) {
	int total=0;
	int a[]={12,13,14,44};
	for(int i:a){
		total=total+i;
	}
System.out.println("Total:"+total);
	}

}
