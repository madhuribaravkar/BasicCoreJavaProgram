package com.BasicProgram;
import java.util.Scanner;
public class SplitString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  String s1="java string split method by javatpoint";
  String[]words=s1.split("\\s");
  for(String w:words){
	  System.out.println(w);
  }
	}

}
