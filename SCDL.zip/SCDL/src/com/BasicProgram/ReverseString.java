package com.BasicProgram;
import java.util.Scanner;
 class StringFormatter{
public static String reverseString(String str){
	StringBuilder sb=new StringBuilder(str);
	sb.reverse();
	return sb.toString();
}
}
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println(StringFormatter.reverseString("my name is madhuri"));
   System.out.println(StringFormatter.reverseString("i am madhuri baravkar"));
  
	}

}
