package com.BasicProgram;
import java.util.Scanner;
public class Swapping7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("enter two number a & b:");
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
a=a+b;
b=a-b;
a=a-b;
System.out.println("Swapping two number a: "+a+"\n b: "+b);

	}

}
