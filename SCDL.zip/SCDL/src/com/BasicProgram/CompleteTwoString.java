package com.BasicProgram;
import java.util.Scanner;
public class CompleteTwoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="madhuri";
String s2="monika";
System.out.println(s1.equals(s2));
	}

}
