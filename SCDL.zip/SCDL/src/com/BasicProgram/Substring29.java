package com.BasicProgram;
import java.util.Scanner;
public class Substring29 {

	public static void main(String[] args) {
	String s="madhuribaravkar";
	System.out.println("Original string:"+s);
	System.out.println("Substring start from index:"+s.substring(7));
	System.out.println("Substring start from index:"+s.substring(0,7));

	}

}
