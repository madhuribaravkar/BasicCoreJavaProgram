package com.BasicProgram;
import java.util.Scanner;
public class ScannerProgram4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter your name:");
Scanner sc=new Scanner(System.in);
String s1=sc.next();
System.out.println("print string:"+s1);
	}

}
