package com.BasicProgram;
import java.util.Scanner;
public class ReplaceString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="my name is madhuri and my surname is baravkar ";
String replaceString=s1.replace("is", "was");
System.out.println(replaceString);
	}

}
