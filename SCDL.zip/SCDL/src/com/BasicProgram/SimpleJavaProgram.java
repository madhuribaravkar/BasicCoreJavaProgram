package com.BasicProgram;
import java.util.Scanner;
public class SimpleJavaProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Hello Java");
	}

}
