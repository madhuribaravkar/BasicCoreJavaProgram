package com.BasicProgram;
import java.util.Scanner;
public class ConstructorOverloading48 {
int id;
String name;
ConstructorOverloading48(){
	System.out.println("this is Default constructor");
}
//parameterised constructor
ConstructorOverloading48(int i,String n){
	id=i;
	name=n;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
  ConstructorOverloading48 co=new ConstructorOverloading48();
  System.out.println("\n Default constructor values:\n");
  System.out.println("student id: "+co.id+"\n student name: "+co.name);
  
  System.out.println("\n parameterised constructor values:\n");
  ConstructorOverloading48 c=new ConstructorOverloading48(10,"madhuri");
  System.out.println("Student id: "+c.id+"\n student name: "+c.name);
	}

}
