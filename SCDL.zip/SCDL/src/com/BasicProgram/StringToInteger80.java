package com.BasicProgram;
import java.util.Scanner;
public class StringToInteger80 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
