package com.BasicProgram;
import java.util.Scanner;
public class SwappingProgram6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a,b,c;
System.out.println("Enter two numbers a & b:");
Scanner sc=new Scanner(System.in);
a=sc.nextInt();
b=sc.nextInt();
c=a;
a=b;
b=c;
System.out.println("Swapping two numbers a :"+a+"\n b: "+b);
	}

}
