package com.BasicProgram;
import java.util.Scanner;
import java.lang.*;
public class NestedIfElse11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int age=25;
int weight=55;
if(age>=18){
	if(weight>=50){
		System.out.println("you are eligible to donate blood");
	}
	else{
		System.out.println("you are not eligible to donate blood");
	}
}
else{
	System.out.println("age must be greater than 18");
}
	
}
	

}
