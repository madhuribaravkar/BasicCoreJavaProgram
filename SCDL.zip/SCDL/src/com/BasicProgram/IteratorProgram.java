package com.BasicProgram;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class IteratorProgram {
    public static void main(String[] args) {
	HashSet<Integer>hash=new HashSet<Integer>();
	hash.add(1);
	hash.add(2);
	hash.add(3);
	hash.add(4);
	hash.add(5);
Iterator<Integer>i=hash.iterator();

while(i.hasNext()) {
	System.out.println(i.next());
}
}
}
