package com.BasicProgram;
import java.util.Scanner;
public class MethodProgram42 {

	public static void main (String[] args) {
		
	}

}
