package com.BasicProgram;
import java.util.Scanner;
public class CommandlineArgument3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("your first argument is:"+args[0]);
for(int i=0;i<args.length;i++)
	System.out.println(args[i]);
	}
}
