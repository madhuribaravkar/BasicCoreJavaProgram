package com.BasicProgram;
import java.util.Scanner;
public class Compare2String35 {

public static void main(String[] args) {
		
System.out.println("Enter two string:");
Scanner sc=new Scanner(System.in);
String s1=sc.next();
String s2=sc.next();
System.out.println(s1.equals(s2));
 
 }
}