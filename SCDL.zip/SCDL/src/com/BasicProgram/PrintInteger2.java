package com.BasicProgram;
import java.util.Scanner;
public class PrintInteger2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a,b,c;
System.out.println("Enter number:");
Scanner sc=new Scanner(System.in);
a=sc.nextInt();
System.out.println("print integer number:"+a);

	}

}
