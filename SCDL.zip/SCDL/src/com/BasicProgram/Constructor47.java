package com.BasicProgram;
import java.util.Scanner;
public class Constructor47 {
Constructor47(){
	System.out.println("Bike is Created");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Constructor47 c=new Constructor47();
	}

}
