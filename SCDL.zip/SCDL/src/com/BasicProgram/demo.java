package com.BasicProgram;

import java.util.ArrayList;

public class demo {
	public static void main(String[] args) {
		System.out.println();
		ArrayList al = new ArrayList<>();

	}
}
