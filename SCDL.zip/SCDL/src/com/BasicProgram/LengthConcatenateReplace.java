package com.BasicProgram;
import java.util.Scanner;
public class LengthConcatenateReplace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    String s="Madhuri"+"Baravkar";
    String s1="javatpoint";
    System.out.println("Concatanation: "+s);
    System.out.println("String Length is:"+s1.length());
    String replaceString=s1.replace('j', 'g');
    System.out.println("Replace String: "+replaceString);
	}

}
