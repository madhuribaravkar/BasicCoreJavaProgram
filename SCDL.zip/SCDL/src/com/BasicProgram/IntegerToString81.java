package com.BasicProgram;
import java.util.Scanner;
public class IntegerToString81 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int i=200;
    String s=String.valueOf(i);
    System.out.println(s);
	}

}
